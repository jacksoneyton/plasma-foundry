#!/usr/bin/env bash
# Shared constants and helpers for the Nightfall scripts.
# Sourced by lib/*.sh — not meant to be run directly.

NF_FONT_UI="Inter,10,-1,5,50,0,0,0,0,0"
NF_FONT_UI_SMALL="Inter,8,-1,5,50,0,0,0,0,0"
NF_FONT_FIXED="JetBrains Mono,10,-1,5,50,0,0,0,0,0"
NF_ACCENT_RGB="111,143,250"

log()  { printf '\033[1;38;5;111m==>\033[0m %s\n' "$1"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$1" >&2; }

# Prints one of: apt dnf zypper pacman unknown
nf_pkg_manager() {
  if command -v apt-get > /dev/null 2>&1; then echo apt
  elif command -v dnf > /dev/null 2>&1; then echo dnf
  elif command -v zypper > /dev/null 2>&1; then echo zypper
  elif command -v pacman > /dev/null 2>&1; then echo pacman
  else echo unknown
  fi
}

# Best-effort install of $1 (same package name across apt/dnf/zypper/pacman
# for everything we use this for — papirus-icon-theme and breeze-gtk are
# consistently named upstream across distros). Never fails the caller;
# just warns and returns nonzero so the caller can fall back.
nf_pkg_install() {
  local pkg="$1"
  case "$(nf_pkg_manager)" in
    apt) apt-get install -y "$pkg" ;;
    dnf) dnf install -y "$pkg" ;;
    zypper) zypper --non-interactive install "$pkg" ;;
    pacman) pacman -S --noconfirm --needed "$pkg" ;;
    *) warn "No supported package manager found (looked for apt/dnf/zypper/pacman) — skipping $pkg"; return 1 ;;
  esac
}

# Downloads $1 to $2 using whichever of curl/wget is available.
nf_fetch() {
  local url="$1" out="$2"
  if command -v curl > /dev/null 2>&1; then
    curl -fsSL -o "$out" "$url"
  elif command -v wget > /dev/null 2>&1; then
    wget -q -O "$out" "$url"
  else
    warn "Neither curl nor wget is available — can't download $url"
    return 1
  fi
}
