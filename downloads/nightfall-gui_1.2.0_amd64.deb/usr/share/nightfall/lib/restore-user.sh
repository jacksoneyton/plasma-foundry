#!/usr/bin/env bash
# Restores the non-root config a Nightfall backup captured. Run as the
# normal user (needs the D-Bus session to reload Plasma).
#
# Usage: restore-user.sh <backup-dir>
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

BACKUP_DIR="${1:?Usage: restore-user.sh <backup-dir>}"
[ -d "$BACKUP_DIR" ] || { warn "Backup directory not found: $BACKUP_DIR"; exit 1; }

for f in kdeglobals plasmarc kwinrc kcminputrc konsolerc kscreenlockerrc ksplashrc; do
  if [ -f "$BACKUP_DIR/$f" ]; then
    cp -a "$BACKUP_DIR/$f" "$HOME/.config/$f"
    log "Restored $f"
  fi
done
if [ -d "$BACKUP_DIR/gtk-3.0" ]; then
  cp -a "$BACKUP_DIR/gtk-3.0" "$HOME/.config/"
  log "Restored gtk-3.0 settings"
fi
if [ -d "$BACKUP_DIR/gtk-4.0" ]; then
  cp -a "$BACKUP_DIR/gtk-4.0" "$HOME/.config/"
  log "Restored gtk-4.0 settings"
fi
if [ -d "$BACKUP_DIR/konsole-profiles" ]; then
  cp -a "$BACKUP_DIR/konsole-profiles/." "$HOME/.local/share/konsole/"
  log "Restored Konsole profiles"
fi

log "Reloading Plasma"
kbuildsycoca6 --noincremental > /dev/null 2>&1 || true
qdbus6 org.kde.KWin /KWin org.kde.KWin.reconfigure > /dev/null 2>&1 || true
(plasmashell --replace > /dev/null 2>&1 &) || true

log "User-level restore complete"
