#!/usr/bin/env bash
# Back up everything Nightfall is about to touch. Runs entirely as the
# invoking user — /etc/sddm.conf.d and the SDDM theme.conf.user are both
# world-readable, so no privilege is needed just to read them.
#
# Usage: backup.sh <backup-dir>
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

BACKUP_DIR="${1:?Usage: backup.sh <backup-dir>}"

log "Backing up your current config to $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
for f in kdeglobals plasmarc kwinrc kcminputrc konsolerc kscreenlockerrc ksplashrc; do
  [ -f "$HOME/.config/$f" ] && cp -a "$HOME/.config/$f" "$BACKUP_DIR/"
done
[ -d "$HOME/.config/gtk-3.0" ] && cp -a "$HOME/.config/gtk-3.0" "$BACKUP_DIR/"
[ -d "$HOME/.config/gtk-4.0" ] && cp -a "$HOME/.config/gtk-4.0" "$BACKUP_DIR/"
[ -d "$HOME/.local/share/konsole" ] && cp -a "$HOME/.local/share/konsole" "$BACKUP_DIR/konsole-profiles"

mkdir -p "$BACKUP_DIR/sddm-etc"
cp -a /etc/sddm.conf.d/. "$BACKUP_DIR/sddm-etc/" 2> /dev/null || true
cp -a /usr/share/sddm/themes/breeze/theme.conf.user "$BACKUP_DIR/breeze-theme.conf.user.orig" 2> /dev/null || true

echo "$BACKUP_DIR" > "$HOME/.nightfall-last-backup"
log "Backup complete"
