#!/usr/bin/env bash
# Restores the root-owned config a Nightfall backup captured (SDDM). Meant
# to be run as root — via `sudo` from uninstall.sh, or via `pkexec` from
# the GUI.
#
# Usage: restore-privileged.sh <backup-dir>
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

if [ "$(id -u)" -ne 0 ]; then
  warn "restore-privileged.sh must run as root (use sudo or pkexec)"
  exit 1
fi

BACKUP_DIR="${1:?Usage: restore-privileged.sh <backup-dir>}"
[ -d "$BACKUP_DIR" ] || { warn "Backup directory not found: $BACKUP_DIR"; exit 1; }

if [ -d "$BACKUP_DIR/sddm-etc" ]; then
  log "Restoring SDDM config"
  cp -a "$BACKUP_DIR/sddm-etc/." /etc/sddm.conf.d/
  rm -f /etc/sddm.conf.d/nightfall.conf
  if [ -f "$BACKUP_DIR/breeze-theme.conf.user.orig" ]; then
    cp -a "$BACKUP_DIR/breeze-theme.conf.user.orig" /usr/share/sddm/themes/breeze/theme.conf.user
  else
    rm -f /usr/share/sddm/themes/breeze/theme.conf.user
  fi
  rm -f /usr/share/sddm/themes/breeze/nightfall-bg.png
  log "Privileged restore complete"
else
  log "No SDDM changes in this backup — nothing to do"
fi
