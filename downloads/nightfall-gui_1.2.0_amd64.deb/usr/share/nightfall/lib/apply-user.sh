#!/usr/bin/env bash
# Applies every part of Nightfall that does NOT need root: color scheme,
# icons, cursor, panel theme, fonts, accent color, widget style, GTK sync,
# Konsole, and the wallpaper. Safe to run as the logged-in user directly —
# it needs the user's own D-Bus session (for plasma-apply-*), so never run
# this one via sudo/pkexec.
#
# Usage: apply-user.sh <repo-dir> [--no-wallpaper] [--keep-style] [--no-packages]
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

REPO_DIR="${1:?Usage: apply-user.sh <repo-dir> [--no-wallpaper] [--keep-style] [--no-packages]}"
shift
DO_WALLPAPER=1
DO_STYLE=1
DO_PACKAGES=1
for arg in "$@"; do
  case "$arg" in
    --no-wallpaper) DO_WALLPAPER=0 ;;
    --keep-style) DO_STYLE=0 ;;
    --no-packages) DO_PACKAGES=0 ;;
    *) warn "apply-user.sh: ignoring unknown option $arg" ;;
  esac
done

for cmd in kwriteconfig6 plasma-apply-colorscheme plasma-apply-cursortheme plasma-apply-desktoptheme; do
  if ! command -v "$cmd" > /dev/null 2>&1; then
    warn "Required command '$cmd' not found. Is this Plasma 6? Aborting."
    exit 1
  fi
done

if [ "$DO_PACKAGES" -eq 1 ]; then
  "$SCRIPT_DIR/install-assets.sh"
else
  log "Skipping font/icon/cursor install (--no-packages)"
fi

log "Installing the Nightfall color scheme"
mkdir -p "$HOME/.local/share/color-schemes"
cp "$REPO_DIR/color-schemes/Nightfall.colors" "$HOME/.local/share/color-schemes/"
plasma-apply-colorscheme Nightfall

log "Setting icon theme (Papirus-Dark)"
kwriteconfig6 --file kdeglobals --group Icons --key Theme Papirus-Dark

log "Setting cursor theme (Bibata-Modern-Ice)"
plasma-apply-cursortheme Bibata-Modern-Ice 2> /dev/null || warn "Bibata-Modern-Ice not found — install bibata-cursor-theme first"

log "Setting Plasma panel theme (breeze-dark)"
plasma-apply-desktoptheme breeze-dark 2> /dev/null || warn "Could not set desktop theme, skipping"

log "Setting accent color"
kwriteconfig6 --file kdeglobals --group General --key AccentColor "$NF_ACCENT_RGB"
kwriteconfig6 --file kdeglobals --group General --key AccentColorFromWallpaper false

log "Setting fonts (Inter / JetBrains Mono)"
kwriteconfig6 --file kdeglobals --group General --key font "$NF_FONT_UI"
kwriteconfig6 --file kdeglobals --group General --key menuFont "$NF_FONT_UI"
kwriteconfig6 --file kdeglobals --group General --key toolBarFont "$NF_FONT_UI"
kwriteconfig6 --file kdeglobals --group General --key smallestReadableFont "$NF_FONT_UI_SMALL"
kwriteconfig6 --file kdeglobals --group General --key fixed "$NF_FONT_FIXED"
kwriteconfig6 --file kdeglobals --group WM --key activeFont "$NF_FONT_UI"

if [ "$DO_STYLE" -eq 1 ]; then
  log "Setting Qt widget style + window decoration (Breeze)"
  kwriteconfig6 --file kdeglobals --group KDE --key widgetStyle Breeze
  kwriteconfig6 --file kwinrc --group org.kde.kdecoration2 --key library org.kde.breeze
  kwriteconfig6 --file kwinrc --group org.kde.kdecoration2 --key theme --delete 2> /dev/null || true
else
  log "Leaving your current widget style/window decoration alone (--keep-style)"
fi

log "Syncing GTK apps (Firefox, GIMP, etc.) to match"
set_ini_key() {
  local file="$1" key="$2" value="$3"
  mkdir -p "$(dirname "$file")"
  touch "$file"
  if ! grep -q '^\[Settings\]' "$file" 2> /dev/null; then
    printf '[Settings]\n' >> "$file"
  fi
  if grep -q "^${key}=" "$file"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$file"
  else
    awk -v k="$key" -v v="$value" '
      { print }
      /^\[Settings\]/ && !done { print k"="v; done=1 }
    ' "$file" > "$file.tmp" && mv "$file.tmp" "$file"
  fi
}
for gtkfile in "$HOME/.config/gtk-3.0/settings.ini" "$HOME/.config/gtk-4.0/settings.ini"; do
  set_ini_key "$gtkfile" gtk-application-prefer-dark-theme true
  set_ini_key "$gtkfile" gtk-theme-name Breeze-Dark
  set_ini_key "$gtkfile" gtk-icon-theme-name Papirus-Dark
  set_ini_key "$gtkfile" gtk-cursor-theme-name Bibata-Modern-Ice
  set_ini_key "$gtkfile" gtk-cursor-theme-size 24
  set_ini_key "$gtkfile" gtk-font-name "Inter 10"
done

# Captured first rather than piped into `grep -q`: under pipefail, grep's
# early exit on match would SIGPIPE gsettings and read as pipeline failure.
GSETTINGS_SCHEMAS=""
if command -v gsettings > /dev/null 2>&1; then
  GSETTINGS_SCHEMAS="$(gsettings list-schemas 2> /dev/null || true)"
fi
if grep -q org.gnome.desktop.interface <<< "$GSETTINGS_SCHEMAS"; then
  gsettings set org.gnome.desktop.interface gtk-theme 'Breeze-Dark' 2> /dev/null || true
  gsettings set org.gnome.desktop.interface icon-theme 'Papirus-Dark' 2> /dev/null || true
  gsettings set org.gnome.desktop.interface cursor-theme 'Bibata-Modern-Ice' 2> /dev/null || true
  gsettings set org.gnome.desktop.interface font-name 'Inter 10' 2> /dev/null || true
  gsettings set org.gnome.desktop.interface monospace-font-name 'JetBrains Mono 10' 2> /dev/null || true
  gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark' 2> /dev/null || true
fi

log "Installing the Konsole profile"
mkdir -p "$HOME/.local/share/konsole"
cp "$REPO_DIR/konsole/Nightfall.colorscheme" "$HOME/.local/share/konsole/"
cp "$REPO_DIR/konsole/Nightfall.profile" "$HOME/.local/share/konsole/"
kwriteconfig6 --file konsolerc --group "Desktop Entry" --key DefaultProfile "Nightfall.profile"

if [ "$DO_WALLPAPER" -eq 1 ]; then
  log "Setting the wallpaper"
  mkdir -p "$HOME/Pictures/Wallpapers"
  cp "$REPO_DIR/wallpaper/nightfall-wallpaper.png" "$HOME/Pictures/Wallpapers/nightfall.png"
  plasma-apply-wallpaperimage "$HOME/Pictures/Wallpapers/nightfall.png" 2> /dev/null || true
  kwriteconfig6 --file kscreenlockerrc --group "Greeter][Wallpaper][org.kde.image][General" \
    --key Image "file://$HOME/Pictures/Wallpapers/nightfall.png"
  kwriteconfig6 --file kscreenlockerrc --group "Greeter][Wallpaper][org.kde.image][General" \
    --key PreviewImage "file://$HOME/Pictures/Wallpapers/nightfall.png"
else
  log "Skipping wallpaper (--no-wallpaper)"
fi

log "Reloading Plasma"
kbuildsycoca6 --noincremental > /dev/null 2>&1 || true
qdbus6 org.kde.KWin /KWin org.kde.KWin.reconfigure > /dev/null 2>&1 || true
(plasmashell --replace > /dev/null 2>&1 &) || true

log "User-level apply complete"
