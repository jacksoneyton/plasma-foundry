#!/usr/bin/env bash
# Applies the parts of Nightfall that need root: the distro-package fast
# path for icons/GTK theme/cursor (papirus-icon-theme, breeze-gtk,
# bibata-cursor-theme — all consistently named across apt/dnf/zypper/pacman),
# and configuring the SDDM login screen. Meant to be run as root — via
# `sudo` from install.sh, or via `pkexec` from the GUI. Because pkexec
# strips the caller's environment, this script takes everything as explicit
# arguments rather than reading env vars.
#
# Fonts, and the icon/cursor fallback when a distro doesn't package them,
# are handled unprivileged in lib/install-assets.sh (called from
# apply-user.sh) — nothing here is load-bearing for Nightfall to work, it
# just avoids a multi-hundred-MB fallback download when the distro already
# has these packaged.
#
# Usage: apply-privileged.sh <repo-dir> [--no-packages] [--sddm] [--no-wallpaper]
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

if [ "$(id -u)" -ne 0 ]; then
  warn "apply-privileged.sh must run as root (use sudo or pkexec)"
  exit 1
fi

REPO_DIR="${1:?Usage: apply-privileged.sh <repo-dir> [--no-packages] [--sddm] [--no-wallpaper]}"
shift
DO_PACKAGES=1
DO_SDDM=0
DO_WALLPAPER=1
for arg in "$@"; do
  case "$arg" in
    --no-packages) DO_PACKAGES=0 ;;
    --sddm) DO_SDDM=1 ;;
    --no-wallpaper) DO_WALLPAPER=0 ;;
    *) warn "apply-privileged.sh: ignoring unknown option $arg" ;;
  esac
done

if [ "$DO_PACKAGES" -eq 1 ]; then
  PKG_MGR="$(nf_pkg_manager)"
  if [ "$PKG_MGR" = "unknown" ]; then
    warn "No supported package manager found (looked for apt/dnf/zypper/pacman)."
    warn "Icons and cursors will still work via the direct-download fallback in install-assets.sh; the GTK theme won't be installed."
  else
    log "Installing icon theme, cursor theme, and GTK theme via $PKG_MGR"
    if [ "$PKG_MGR" = "apt" ]; then
      apt-get update -qq || warn "apt-get update failed — continuing with whatever package lists are already cached"
    fi
    # Best-effort per package: one being unavailable on this distro
    # shouldn't block the others.
    nf_pkg_install papirus-icon-theme || warn "papirus-icon-theme not available via $PKG_MGR — install-assets.sh will fetch it directly instead"
    nf_pkg_install bibata-cursor-theme || warn "bibata-cursor-theme not available via $PKG_MGR — install-assets.sh will fetch it directly instead"
    nf_pkg_install breeze-gtk || warn "breeze-gtk not available via $PKG_MGR — GTK apps will keep your system's default GTK theme"
  fi
else
  log "Skipping package installation (--no-packages)"
fi

if [ "$DO_SDDM" -eq 1 ]; then
  if [ -d /usr/share/sddm/themes/breeze ]; then
    log "Configuring the SDDM login screen"
    if [ "$DO_WALLPAPER" -eq 1 ]; then
      cp "$REPO_DIR/wallpaper/nightfall-wallpaper.png" /usr/share/sddm/themes/breeze/nightfall-bg.png
      chmod 644 /usr/share/sddm/themes/breeze/nightfall-bg.png
    fi
    cp "$REPO_DIR/sddm/breeze-theme.conf.user" /usr/share/sddm/themes/breeze/theme.conf.user
    mkdir -p /etc/sddm.conf.d
    kwriteconfig6 --file /etc/sddm.conf.d/nightfall.conf --group Theme --key Current breeze
    kwriteconfig6 --file /etc/sddm.conf.d/nightfall.conf --group Theme --key CursorTheme Bibata-Modern-Ice
    kwriteconfig6 --file /etc/sddm.conf.d/nightfall.conf --group Theme --key CursorSize 24
    kwriteconfig6 --file /etc/sddm.conf.d/nightfall.conf --group Theme --key Font "Inter,10,-1,5,50,0,0,0,0,0"
    # Captured first rather than chained into `grep -q`: under pipefail, an
    # early-exiting grep further down the pipe SIGPIPEs the one before it,
    # which pipefail then reports as failure even when a match was found.
    OTHER_SDDM_FILES="$(grep -rl "^Current=" /etc/sddm.conf.d/ 2> /dev/null | grep -v nightfall.conf || true)"
    if [ -n "$OTHER_SDDM_FILES" ]; then
      warn "Another file in /etc/sddm.conf.d/ also sets [Theme] Current — it may win depending on load order."
      warn "Check with: grep -r Current /etc/sddm.conf.d/"
    fi
  else
    warn "/usr/share/sddm/themes/breeze not found — skipping SDDM setup"
  fi
fi

log "Privileged apply complete"
