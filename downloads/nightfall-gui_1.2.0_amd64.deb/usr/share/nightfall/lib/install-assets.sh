#!/usr/bin/env bash
# Installs the fonts, icon theme, and cursor theme Nightfall needs, with no
# assumption about which distro or package manager is in play. Runs entirely
# unprivileged, writing into the invoking user's own XDG data dirs — no
# sudo/pkexec here, on purpose (see README for why).
#
# Strategy per asset:
#  - Fonts (Inter, JetBrains Mono): distro packaging for these varies too
#    much to chase (fonts-inter on apt, rsms-inter-fonts on dnf, inter-font
#    on pacman, ...), so always fetch the upstream variable-font release
#    directly. Small (~1-2MB each), works identically everywhere.
#  - Cursor (Bibata-Modern-Ice): same reasoning — always fetch the upstream
#    release tarball directly.
#  - Icons (Papirus-Dark): distro packaging for this IS consistent
#    (papirus-icon-theme on apt/dnf/zypper/pacman alike), so check whether
#    it's already present (installed by lib/apply-privileged.sh's package
#    step, or pre-existing) before falling back to the ~350MB upstream
#    source tarball — that fallback only pays its cost when nothing native
#    provided it.
#
# Usage: install-assets.sh
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh"

FONTS_DIR="$HOME/.local/share/fonts"
ICONS_DIR="$HOME/.local/share/icons"

nf_latest_asset_url() {
  # $1 = owner/repo, $2 = extended-regex matching the asset filename
  curl -fsSL "https://api.github.com/repos/$1/releases/latest" \
    | grep -o '"browser_download_url": *"[^"]*"' \
    | sed -E 's/.*"(https:[^"]+)"/\1/' \
    | grep -E "$2" \
    | head -1
}

install_fonts() {
  # Captured first rather than piped straight into `grep -q`: under
  # `pipefail`, grep's early exit on first match sends fc-list a SIGPIPE,
  # which pipefail then reports as pipeline failure even though grep found
  # what it was looking for.
  local fc_output
  fc_output="$(fc-list)"
  if grep -qi "Inter Variable" <<< "$fc_output" && grep -qi "JetBrains Mono" <<< "$fc_output"; then
    log "Fonts already present, skipping download"
    return 0
  fi

  local tmp
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' RETURN

  log "Fetching Inter (variable font) from rsms/inter"
  local inter_url
  inter_url="$(nf_latest_asset_url rsms/inter 'Inter-[0-9.]+\.zip$')" || true
  if [ -n "$inter_url" ] && nf_fetch "$inter_url" "$tmp/inter.zip" && command -v unzip > /dev/null 2>&1; then
    mkdir -p "$FONTS_DIR/Inter"
    unzip -o -q -j "$tmp/inter.zip" "InterVariable.ttf" "InterVariable-Italic.ttf" -d "$FONTS_DIR/Inter"
  else
    warn "Could not fetch Inter (need a URL from GitHub's API plus curl/wget and unzip) — skipping"
  fi

  log "Fetching JetBrains Mono (variable font) from JetBrains/JetBrainsMono"
  local jbm_url
  jbm_url="$(nf_latest_asset_url JetBrains/JetBrainsMono 'JetBrainsMono-[0-9.]+\.zip$')" || true
  if [ -n "$jbm_url" ] && nf_fetch "$jbm_url" "$tmp/jbmono.zip" && command -v unzip > /dev/null 2>&1; then
    mkdir -p "$FONTS_DIR/JetBrainsMono"
    unzip -o -q -j "$tmp/jbmono.zip" "fonts/variable/*" -d "$FONTS_DIR/JetBrainsMono"
  else
    warn "Could not fetch JetBrains Mono — skipping"
  fi

  fc-cache -f "$FONTS_DIR" > /dev/null 2>&1 || true
}

install_cursor() {
  if [ -d /usr/share/icons/Bibata-Modern-Ice ] || [ -d "$ICONS_DIR/Bibata-Modern-Ice" ]; then
    log "Bibata-Modern-Ice cursor theme already present, skipping download"
    return 0
  fi

  log "Fetching Bibata-Modern-Ice from ful1e5/Bibata_Cursor"
  local tmp
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' RETURN
  if nf_fetch "https://github.com/ful1e5/Bibata_Cursor/releases/latest/download/Bibata-Modern-Ice.tar.xz" "$tmp/bibata.tar.xz"; then
    mkdir -p "$ICONS_DIR"
    tar -xJf "$tmp/bibata.tar.xz" -C "$ICONS_DIR"
  else
    warn "Could not fetch Bibata-Modern-Ice cursors — skipping (falling back to your system's default cursor theme)"
  fi
}

install_icons() {
  if [ -d /usr/share/icons/Papirus-Dark ] || [ -d "$ICONS_DIR/Papirus-Dark" ]; then
    log "Papirus-Dark icon theme already present, skipping download"
    return 0
  fi

  log "Papirus-Dark not found via a package — fetching the upstream source tarball instead (larger download, ~350MB, since Papirus doesn't publish a slim prebuilt release asset)"
  local tmp
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' RETURN
  if nf_fetch "https://github.com/PapirusDevelopmentTeam/papirus-icon-theme/archive/master.tar.gz" "$tmp/papirus.tar.gz"; then
    tar -xzf "$tmp/papirus.tar.gz" -C "$tmp"
    local srcdir
    srcdir="$(find "$tmp" -maxdepth 1 -type d -name 'papirus-icon-theme-*' | head -1)" || true
    if [ -n "$srcdir" ] && [ -d "$srcdir/Papirus-Dark" ]; then
      mkdir -p "$ICONS_DIR"
      cp -r "$srcdir/Papirus-Dark" "$ICONS_DIR/"
      cp -f "$srcdir/AUTHORS" "$srcdir/LICENSE" "$ICONS_DIR/Papirus-Dark/" 2> /dev/null || true
      gtk-update-icon-cache -q "$ICONS_DIR/Papirus-Dark" > /dev/null 2>&1 || true
    else
      warn "Downloaded Papirus source but couldn't find Papirus-Dark inside it — skipping"
    fi
  else
    warn "Could not fetch Papirus-Dark — falling back to your system's default icon theme"
  fi
}

install_fonts
install_icons
install_cursor
log "Asset install complete"
